<template>
    <div class="FirstBottomPage">
        <a href="http://beian.gov.cn/portal/index.do">粤ICP备19140452号-1</a> | Copyright © 2019-present 裂泉
    </div>
</template>

<script>
    export default {
        
    }
</script>

<style>
.FirstBottomPage{
    border-top: 1px solid #eaecef;
    padding-top: 30px;
    margin-top: 40px;
    text-align: center;
}
</style>