<template>
    <div>
        <div style="width:100%;backgroundColor:#ebebeb;padding:30px;height:100vh;">
            <div style="minWidth:350px;width:40%;margin:auto;">
                <div style="marginBottom:15px;fontSize:18px;fontWeight:bold;color:#293f5f;">
                    hahah
                </div>
                <div style="width:100%;height:100%;backgroundColor:#ffffff;margin:auto;;padding:40px 20px;fontSize:14px;">
                    <div style="marginBottom:30px;">尊敬的
                        <span style="color:#3f50a0;fontWeight:bold;">admin</span>
                        用户，您好！
                    </div>
                    <div>
                        <span>我只是</span>
                        测试一下样式而已啦
                    </div>
                    <div style="margin:auto;marginTop:30px;">
                        <div style="width:130px;height:40px;line-Height:40px;fontSize:15px;
                        backgroundColor:#f8a100;textAlign:center;borderRadius:5px;color:white;margin:auto;">
                        <a href="www.baidu.com" style="color:white">点击一下</a>
                        </div>
                    </div>
                    <div style="marginTop:30px;">
                        你也可以请将以下地址复制到浏览器打开，即可跳转至百度：
                        <span style="color:#f8a100;">
                            https://www.baidu.com/
                        </span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    data() {
        return {
       
        }
    },
}
</script>


<style scoped>
.color{
    color: #f8a100;
}
</style>